CREATE USER 'haproxy'@'%';
